package problem4;

public interface Filter {
}
