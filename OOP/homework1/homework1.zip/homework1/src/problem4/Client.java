package problem4;

public class Client {

    ServerApplication serverApplication = new ServerApplication();

    public static void main(String[] args) {
        // simulate a request from client side
        Request request = new Request();
        request.setIp("192.0.0.8");
        request.setUsername("john");
        request.setPassword("123456");
        // simulate sending request to the server application
        serverApplication.handleRequest(request);
    }
}
