package problem4;

import java.util.ArrayList;
import java.util.List;

public class ServerApplication {
    private List<Filter> filters = new ArrayList();

    public ServerApplication() {
        // add filters here......

    }

    public void handleRequest(Request req) {
        try {
            // let each filter do the job
            for (Filter filter : fitlers) {
                filter.doFilter(req);
            }
        } catch (Exception e) {

        }
    }
}