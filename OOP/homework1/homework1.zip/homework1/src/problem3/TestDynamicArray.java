package problem3;

public class TestDynamicArray {
    public static void test(DynamicArray dynamicArray) {
        dynamicArray.add(5);
        dynamicArray.add(1);
        dynamicArray.add(3);
        for (int i = 0; i < dynamicArray.size(); ++i) {
            System.out.println(dynamicArray.get(i));
        }
        dynamicArray.add(2);
        dynamicArray.add(10);
        dynamicArray.add(32);
        dynamicArray.add(51);
        dynamicArray.delete(3);
        dynamicArray.add(13);
        dynamicArray.add(25);
        dynamicArray.add(-1);
        dynamicArray.add(0);
        for (int i = 0; i < dynamicArray.size(); ++i) {
            System.out.println(dynamicArray.get(i));
        }
    }

    public static void main(String args[]) {
        DynamicArray dynamicArray = new SortedDynamicArray();
        test(dynamicArray);
    }
}
