package zmacadam.project1.app;

import zmacadam.project1.view.MainView;

/**
 * Application starts here.
 * A MainView instance is created.
 * @author bwei
 *
 */
public class MainApp {
	public static void main(String[] args) {
		new MainView().run();
	}
}
